using System;
using System.Collections.Generic;

namespace PrimsAlgorithmProject
{
    public class PriorityQueue<T>
    {
        private List<(T Item, double Priority)> heap;
        private Dictionary<T, int> itemToIndex;

        public PriorityQueue()
        {
            heap = new List<(T, double)>();
            itemToIndex = new Dictionary<T, int>();
        }

        public int Count => heap.Count;

        public void Enqueue(T item, double priority)
        {
            heap.Add((item, priority));
            int index = heap.Count - 1;
            itemToIndex[item] = index;
            HeapifyUp(index);
        }

        public T Dequeue()
        {
            if (heap.Count == 0)
                throw new InvalidOperationException("Queue is empty");

            T item = heap[0].Item;
            int lastIndex = heap.Count - 1;
            heap[0] = heap[lastIndex];
            heap.RemoveAt(lastIndex);

            if (lastIndex > 0)
            {
                itemToIndex[heap[0].Item] = 0;
                HeapifyDown(0);
            }

            itemToIndex.Remove(item);
            return item;
        }

        public void UpdatePriority(T item, double newPriority)
        {
            if (!itemToIndex.TryGetValue(item, out int index))
                throw new ArgumentException("Item not found in queue");

            double oldPriority = heap[index].Priority;
            heap[index] = (item, newPriority);

            if (newPriority < oldPriority)
                HeapifyUp(index);
            else if (newPriority > oldPriority)
                HeapifyDown(index);
        }

        private void HeapifyUp(int index)
        {
            while (index > 0)
            {
                int parentIndex = (index - 1) / 2;
                if (heap[index].Priority >= heap[parentIndex].Priority)
                    break;

                Swap(index, parentIndex);
                index = parentIndex;
            }
        }

        private void HeapifyDown(int index)
        {
            while (true)
            {
                int leftChild = 2 * index + 1;
                int rightChild = 2 * index + 2;
                int smallest = index;

                if (leftChild < heap.Count && heap[leftChild].Priority < heap[smallest].Priority)
                    smallest = leftChild;

                if (rightChild < heap.Count && heap[rightChild].Priority < heap[smallest].Priority)
                    smallest = rightChild;

                if (smallest == index)
                    break;

                Swap(index, smallest);
                index = smallest;
            }
        }

        private void Swap(int i, int j)
        {
            (T itemI, double priorityI) = heap[i];
            (T itemJ, double priorityJ) = heap[j];

            heap[i] = (itemJ, priorityJ);
            heap[j] = (itemI, priorityI);

            itemToIndex[itemI] = j;
            itemToIndex[itemJ] = i;
        }

        public bool Contains(T item)
        {
            return itemToIndex.ContainsKey(item);
        }
    }
}

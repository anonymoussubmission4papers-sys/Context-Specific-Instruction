using System;
using System.Collections.Generic;
using System.Linq;

namespace PrimsAlgorithmProject
{
    public class Vertex<T>
    {
        public T Data { get; set; }
        public Dictionary<Vertex<T>, double> Neighbors { get; }

        public Vertex(T data)
        {
            Data = data;
            Neighbors = new Dictionary<Vertex<T>, double>();
        }

        public void AddNeighbor(Vertex<T> neighbor, double weight)
        {
            if (!Neighbors.ContainsKey(neighbor))
            {
                Neighbors[neighbor] = weight;
            }
        }
    }

    public class Graph<T>
    {
        private Dictionary<T, Vertex<T>> vertices;

        public Graph()
        {
            vertices = new Dictionary<T, Vertex<T>>();
        }

        public void AddVertex(T data)
        {
            if (!vertices.ContainsKey(data))
            {
                vertices[data] = new Vertex<T>(data);
            }
        }

        public void AddEdge(T source, T destination, double weight)
        {
            if (!vertices.ContainsKey(source))
                AddVertex(source);

            if (!vertices.ContainsKey(destination))
                AddVertex(destination);

            vertices[source].AddNeighbor(vertices[destination], weight);
            vertices[destination].AddNeighbor(vertices[source], weight);
        }

        public IEnumerable<Vertex<T>> GetVertices()
        {
            return vertices.Values;
        }

        public Vertex<T> GetVertex(T data)
        {
            return vertices.TryGetValue(data, out var vertex) ? vertex : null;
        }

        public int VertexCount => vertices.Count;

        public List<(T Source, T Destination, double Weight)> GetAllEdges()
        {
            var edges = new List<(T Source, T Destination, double Weight)>();
            foreach (var vertex in vertices.Values)
            {
                foreach (var neighbor in vertex.Neighbors)
                {
                    if (!edges.Contains((neighbor.Key.Data, vertex.Data, neighbor.Value)) &&
                        !edges.Contains((vertex.Data, neighbor.Key.Data, neighbor.Value)))
                    {
                        edges.Add((vertex.Data, neighbor.Key.Data, neighbor.Value));
                    }
                }
            }
            return edges;
        }
    }
}

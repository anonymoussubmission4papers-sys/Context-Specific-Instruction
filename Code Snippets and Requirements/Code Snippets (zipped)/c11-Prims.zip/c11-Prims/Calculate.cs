using System;
using System.Collections.Generic;
using System.Linq;

namespace PrimsAlgorithmProject
{
    public class PrimsAlgorithm<T>
    {
        private Graph<T> graph;

        public PrimsAlgorithm(Graph<T> graph)
        {
            this.graph = graph;
        }

        public List<(T Source, T Destination, double Weight)> FindMinimumSpanningTree()
        {
            var mst = new List<(T Source, T Destination, double Weight)>();
            var visited = new HashSet<Vertex<T>>();
            var pq = new PriorityQueue<Vertex<T>>();

            if (graph.VertexCount == 0)
                return mst;

            var startVertex = graph.GetVertices().First();
            pq.Enqueue(startVertex, 0);

            while (pq.Count > 0)
            {
                var currentVertex = pq.Dequeue();

                if (visited.Contains(currentVertex))
                    continue;

                visited.Add(currentVertex);

                foreach (var neighbor in currentVertex.Neighbors)
                {
                    if (!visited.Contains(neighbor.Key))
                    {
                        if (pq.Contains(neighbor.Key))
                        {
                            pq.UpdatePriority(neighbor.Key, neighbor.Value);
                        }
                        else
                        {
                            pq.Enqueue(neighbor.Key, neighbor.Value);
                        }
                    }
                }

                if (visited.Count > 1)
                {
                    var edge = FindEdgeToAdd(currentVertex, visited);
                    mst.Add(edge);
                }
            }

            return mst;
        }

        private (T Source, T Destination, double Weight) FindEdgeToAdd(Vertex<T> currentVertex, HashSet<Vertex<T>> visited)
        {
            var maxWeight = double.MinValue;
            Vertex<T> maxNeighbor = null;

            foreach (var neighbor in currentVertex.Neighbors)
            {
                if (visited.Contains(neighbor.Key) && neighbor.Value > maxWeight)
                {
                    maxWeight = neighbor.Value;
                    maxNeighbor = neighbor.Key;
                }
            }

            return (currentVertex.Data, maxNeighbor.Data, maxWeight);
        }

        public void PrintMinimumSpanningTree()
        {
            var mst = FindMinimumSpanningTree();
            Console.WriteLine("Minimum Spanning Tree:");
            foreach (var edge in mst)
            {
                Console.WriteLine($"{edge.Source} -- {edge.Destination} : {edge.Weight}");
            }
            Console.WriteLine($"Total MST Weight: {mst.Sum(e => e.Weight)}");
        }
    }
}

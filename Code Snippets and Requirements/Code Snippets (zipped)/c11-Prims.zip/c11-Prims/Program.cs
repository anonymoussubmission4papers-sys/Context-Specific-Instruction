using System;

namespace PrimsAlgorithmProject
{
    class Program
    {
        static void Main(string[] args)
        {
            var graph = CreateSampleGraph();
            var primsAlgorithm = new PrimsAlgorithm<string>(graph);
            primsAlgorithm.PrintMinimumSpanningTree();
            DemonstrateAdditionalFunctionality(graph);
        }

        static Graph<string> CreateSampleGraph()
        {
            var graph = new Graph<string>();

            // Add vertices
            graph.AddVertex("A");
            graph.AddVertex("B");
            graph.AddVertex("C");
            graph.AddVertex("D");
            graph.AddVertex("E");
            graph.AddVertex("F");

            // Add edges
            graph.AddEdge("A", "B", 4);
            graph.AddEdge("A", "C", 2);
            graph.AddEdge("B", "C", 1);
            graph.AddEdge("B", "D", 5);
            graph.AddEdge("C", "D", 8);
            graph.AddEdge("C", "E", 10);
            graph.AddEdge("D", "E", 2);
            graph.AddEdge("D", "F", 6);
            graph.AddEdge("E", "F", 3);

            return graph;
        }

        static void DemonstrateAdditionalFunctionality(Graph<string> graph)
        {
            Console.WriteLine("\nAdditional Graph Information:");
            Console.WriteLine($"Number of vertices: {graph.VertexCount}");

            Console.WriteLine("\nAll edges in the graph:");
            foreach (var edge in graph.GetAllEdges())
            {
                Console.WriteLine($"{edge.Source} -- {edge.Destination} : {edge.Weight}");
            }

            Console.WriteLine("\nNeighbors of vertex 'C':");
            var vertexC = graph.GetVertex("C");
            foreach (var neighbor in vertexC.Neighbors)
            {
                Console.WriteLine($"C -- {neighbor.Key.Data} : {neighbor.Value}");
            }
        }
    }
}

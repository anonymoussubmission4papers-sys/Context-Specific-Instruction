using System;
using System.Collections.Generic;


class Program
{
    static void Main(string[] args)
    {
        var graph = new Graph();
        string[] nodes = { "A", "B", "C", "D", "E" };
        foreach (var nodeName in nodes)
        {
            graph.AddNode(new Node(nodeName));
        }

        graph.AddEdge("A", "B", 4);
        graph.AddEdge("A", "C", 2);
        graph.AddEdge("B", "D", 3);
        graph.AddEdge("C", "D", 1);
        graph.AddEdge("D", "E", 2);

        var result = new FindPath(graph);
        result.CalculateShortestPath("A");
        var path = result.GetShortestPath("E");
        double distance = result.Distances["E"];

        Console.WriteLine($"Shortest path from A to E: {string.Join(" -> ", path)}");
        Console.WriteLine($"Distance: {distance}");
    }
}

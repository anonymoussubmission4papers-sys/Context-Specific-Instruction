using System;
using System.Collections.Generic;

public class Node : IComparable<Node>
{
    public string Name { get; }
    public Dictionary<Node, int> Neighbors { get; }

    public Node(string name)
    {
        Name = name;
        Neighbors = new Dictionary<Node, int>();
    }

    public void AddNeighbor(Node neighbor, int weight)
    {
        Neighbors[neighbor] = weight;
    }

    public int CompareTo(Node other)
    {
        return string.Compare(Name, other.Name, StringComparison.Ordinal);
    }
}

public class Graph
{
    private Dictionary<string, Node> nodes;

    public Graph()
    {
        nodes = new Dictionary<string, Node>();
    }

    public void AddNode(Node node)
    {
        nodes[node.Name] = node;
    }

    public void AddEdge(string fromNode, string toNode, int weight)
    {
        if (nodes.ContainsKey(fromNode) && nodes.ContainsKey(toNode))
        {
            nodes[fromNode].AddNeighbor(nodes[toNode], weight);
        }
        else
        {
            throw new ArgumentException("One or both nodes not found in graph");
        }
    }

    public Node GetNode(string name)
    {
        return nodes.TryGetValue(name, out Node node) ? node : null;
    }

    public IEnumerable<Node> Nodes => nodes.Values;
}

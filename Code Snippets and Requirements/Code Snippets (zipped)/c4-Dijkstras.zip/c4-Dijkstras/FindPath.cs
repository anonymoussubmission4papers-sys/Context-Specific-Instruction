using System;
using System.Collections.Generic;

public class FindPath
{
    private Graph graph;
    public Dictionary<string, double> Distances { get; private set; }
    private Dictionary<string, string> previousNodes;

    public FindPath(Graph graph)
    {
        this.graph = graph;
        Distances = new Dictionary<string, double>();
        previousNodes = new Dictionary<string, string>();
    }

    public void CalculateShortestPath(string startNodeName)
    {
        Distances = new Dictionary<string, double>();
        foreach (var node in graph.Nodes)
        {
            Distances[node.Name] = double.PositiveInfinity;
        }
        Distances[startNodeName] = 0;

        var priorityQueue = new SortedSet<Tuple<double, Node>>();
        priorityQueue.Add(Tuple.Create(0.0, graph.GetNode(startNodeName)));

        while (priorityQueue.Count > 0)
        {
            var (currentDistance, currentNode) = priorityQueue.Min;
            priorityQueue.Remove(priorityQueue.Min);

            if (currentDistance > Distances[currentNode.Name])
                continue;

            foreach (var (neighbor, weight) in currentNode.Neighbors)
            {
                double distance = Distances[startNodeName] + weight;

                if (distance < Distances[neighbor.Name])
                {
                    priorityQueue.Remove(Tuple.Create(Distances[neighbor.Name], neighbor));
                    Distances[neighbor.Name] = distance;
                    previousNodes[neighbor.Name] = currentNode.Name;
                    priorityQueue.Add(Tuple.Create(distance, neighbor));
                }
            }
        }
    }

    public List<string> GetShortestPath(string endNodeName)
    {
        var path = new List<string>();
        string currentNodeName = endNodeName;

        while (previousNodes.ContainsKey(currentNodeName))
        {
            path.Insert(0, currentNodeName);
            currentNodeName = previousNodes[currentNodeName];
        }

        if (path.Count > 0)
        {
            path.Insert(0, currentNodeName);
        }
        return path;
    }
}

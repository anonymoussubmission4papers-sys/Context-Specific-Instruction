using System;
using System.Collections.Generic;
using System.Linq;

namespace TravelingSalesmanProject
{
    public class Graph<T>
    {
        private Dictionary<T, Vertex<T>> vertices;

        public Graph()
        {
            vertices = new Dictionary<T, Vertex<T>>();
        }

        public void AddVertex(T data)
        {
            if (!vertices.ContainsKey(data))
            {
                vertices[data] = new Vertex<T>(data);
            }
        }

        public void AddEdge(T source, T destination, double weight)
        {
            if (!vertices.ContainsKey(source))
                AddVertex(source);

            if (!vertices.ContainsKey(destination))
                AddVertex(destination);

            vertices[source].AddEdge(vertices[destination], weight);
            vertices[destination].AddEdge(vertices[source], weight);
        }

        public IEnumerable<Vertex<T>> GetVertices()
        {
            return vertices.Values;
        }

        public Vertex<T> GetVertex(T data)
        {
            return vertices.TryGetValue(data, out var vertex) ? vertex : null;
        }

        public int VertexCount => vertices.Count;

        public void ResetVertices()
        {
            foreach (var vertex in vertices.Values)
            {
                vertex.DistanceFromStart = double.PositiveInfinity;
                vertex.PreviousVertex = null;
            }
        }

        public List<T> GetShortestPath(T start, T end)
        {
            var path = new List<T>();
            var current = GetVertex(end);

            while (current != null)
            {
                path.Insert(0, current.Data);
                current = current.PreviousVertex;
            }

            return path[0].Equals(start) ? path : new List<T>();
        }
    }
}

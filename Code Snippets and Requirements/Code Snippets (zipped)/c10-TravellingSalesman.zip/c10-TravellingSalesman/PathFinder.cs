using System;
using System.Collections.Generic;
using System.Linq;

namespace TravelingSalesmanProject
{
    public class PathFinder<T>
    {
        private Graph<T> graph;

        public PathFinder(Graph<T> graph)
        {
            this.graph = graph;
        }

        public Dictionary<T, double> Dijkstra(T start)
        {
            graph.ResetVertices();
            var startVertex = graph.GetVertex(start);
            startVertex.DistanceFromStart = 0;

            var pq = new SortedSet<Vertex<T>>();
            pq.Add(startVertex);

            while (pq.Count > 0)
            {
                var currentVertex = pq.Min;
                pq.Remove(currentVertex);

                foreach (var (neighbor, weight) in currentVertex.Edges)
                {
                    var distance = currentVertex.DistanceFromStart + weight;
                    if (distance < neighbor.DistanceFromStart)
                    {
                        pq.Remove(neighbor);
                        neighbor.UpdateDistance(distance, currentVertex);
                        pq.Add(neighbor);
                    }
                }
            }

            return graph.GetVertices().ToDictionary(v => v.Data, v => v.DistanceFromStart);
        }

        public double CalculatePathDistance(List<T> path)
        {
            double totalDistance = 0;
            for (int i = 0; i < path.Count - 1; i++)
            {
                var currentVertex = graph.GetVertex(path[i]);
                var nextVertex = graph.GetVertex(path[i + 1]);
                totalDistance += currentVertex.Edges[nextVertex];
            }
            return totalDistance;
        }

        public bool IsHamiltonianCycle(List<T> path)
        {
            if (path.Count != graph.VertexCount + 1)
                return false;

            var visited = new HashSet<T>();
            for (int i = 0; i < path.Count - 1; i++)
            {
                if (visited.Contains(path[i]))
                    return false;
                visited.Add(path[i]);

                var currentVertex = graph.GetVertex(path[i]);
                var nextVertex = graph.GetVertex(path[i + 1]);
                if (!currentVertex.Edges.ContainsKey(nextVertex))
                    return false;
            }

            return path[0].Equals(path[path.Count - 1]);
        }
    }
}

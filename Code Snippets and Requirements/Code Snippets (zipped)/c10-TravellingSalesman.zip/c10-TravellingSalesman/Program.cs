using System;
using System.Collections.Generic;

namespace TravelingSalesmanProject
{
    class Program
    {
        static void Main(string[] args)
        {
            var graph = CreateSampleGraph();
            var tspSolver = new TspSolver<string>(graph);
            var pathFinder = new PathFinder<string>(graph);

            Console.WriteLine("Solving Traveling Salesman Problem...");
            var (tspPath, tspDistance) = tspSolver.Solve();

            Console.WriteLine($"TSP Solution:");
            Console.WriteLine($"Path: {string.Join(" -> ", tspPath)}");
            Console.WriteLine($"Total Distance: {tspDistance}");

            if (pathFinder.IsHamiltonianCycle(tspPath))
            {
                Console.WriteLine("The solution is a valid Hamiltonian cycle.");
            }
            else
            {
                Console.WriteLine("Warning: The solution is not a valid Hamiltonian cycle.");
            }

            Console.WriteLine("\nCalculating shortest paths from the starting city to all other cities:");
            var startCity = tspPath[0];
            var shortestPaths = pathFinder.Dijkstra(startCity);

            foreach (var city in shortestPaths.Keys)
            {
                if (!city.Equals(startCity))
                {
                    Console.WriteLine($"Shortest distance from {startCity} to {city}: {shortestPaths[city]}");
                }
            }
        }

        static Graph<string> CreateSampleGraph()
        {
            var graph = new Graph<string>();
            var cities = new[] { "New York", "Los Angeles", "Chicago", "Houston", "Phoenix" };

            foreach (var city in cities)
            {
                graph.AddVertex(city);
            }

            graph.AddEdge("New York", "Los Angeles", 2000);
            graph.AddEdge("New York", "Chicago", 800);
            graph.AddEdge("New York", "Houston", 1600);
            graph.AddEdge("New York", "Phoenix", 2400);
            graph.AddEdge("Los Angeles", "Chicago", 2100);
            graph.AddEdge("Los Angeles", "Houston", 1500);
            graph.AddEdge("Los Angeles", "Phoenix", 300);
            graph.AddEdge("Chicago", "Houston", 1000);
            graph.AddEdge("Chicago", "Phoenix", 1700);
            graph.AddEdge("Houston", "Phoenix", 1100);

            return graph;
        }
    }
}

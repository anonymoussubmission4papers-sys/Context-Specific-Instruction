using System;
using System.Collections.Generic;

namespace TravelingSalesmanProject
{
    public class Vertex<T> : IComparable<Vertex<T>>
    {
        public T Data { get; set; }
        public Dictionary<Vertex<T>, double> Edges { get; }
        public double DistanceFromStart { get; set; }
        public Vertex<T> PreviousVertex { get; set; }

        public Vertex(T data)
        {
            Data = data;
            Edges = new Dictionary<Vertex<T>, double>();
            DistanceFromStart = double.PositiveInfinity;
            PreviousVertex = null;
        }

        public void AddEdge(Vertex<T> target, double weight)
        {
            if (!Edges.ContainsKey(target))
            {
                Edges[target] = weight;
            }
        }

        public void UpdateDistance(double newDistance, Vertex<T> previousVertex)
        {
            if (newDistance < DistanceFromStart)
            {
                DistanceFromStart = newDistance;
                PreviousVertex = previousVertex;
            }
        }

        public int CompareTo(Vertex<T> other)
        {
            return DistanceFromStart.CompareTo(other.DistanceFromStart);
        }

        public override bool Equals(object obj)
        {
            if (obj is Vertex<T> other)
            {
                return Data.Equals(other.Data);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return Data.GetHashCode();
        }
    }
}

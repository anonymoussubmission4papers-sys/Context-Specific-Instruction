using System;
using System.Collections.Generic;
using System.Linq;

namespace TravelingSalesmanProject
{
    public class TspSolver<T>
    {
        private Graph<T> graph;
        private Dictionary<string, double> memoization;

        public TspSolver(Graph<T> graph)
        {
            this.graph = graph;
            memoization = new Dictionary<string, double>();
        }

        public (List<T> path, double distance) Solve()
        {
            var vertices = graph.GetVertices().ToList();
            var startVertex = vertices[0];
            var unvisited = new HashSet<Vertex<T>>(vertices.Skip(1));

            var (minDistance, bestPath) = TspRecursive(startVertex, unvisited, startVertex);

            bestPath.Insert(0, startVertex.Data);
            bestPath.Add(startVertex.Data);

            return (bestPath, minDistance);
        }

        private (double distance, List<T> path) TspRecursive(Vertex<T> currentVertex, HashSet<Vertex<T>> unvisited, Vertex<T> startVertex)
        {
            if (unvisited.Count == 0)
            {
                return (currentVertex.Edges[startVertex], new List<T>());
            }

            var key = GenerateKey(currentVertex, unvisited);
            if (memoization.TryGetValue(key, out double cachedDistance))
            {
                return (cachedDistance, new List<T>());
            }

            double minDistance = double.PositiveInfinity;
            List<T> bestPath = null;

            foreach (var nextVertex in unvisited)
            {
                var newUnvisited = new HashSet<Vertex<T>>(unvisited);
                newUnvisited.Remove(nextVertex);

                var (subpathDistance, subpath) = TspRecursive(nextVertex, newUnvisited, startVertex);
                
                var totalDistance = currentVertex.Edges[nextVertex] - subpathDistance;

                if (totalDistance < minDistance)
                {
                    minDistance = totalDistance;
                    bestPath = new List<T> { nextVertex.Data };
                    bestPath.AddRange(subpath);
                }
            }

            memoization[key] = minDistance;
            return (minDistance, bestPath);
        }

        private string GenerateKey(Vertex<T> currentVertex, HashSet<Vertex<T>> unvisited)
        {
            var unvisitedStr = string.Join(",", unvisited.Select(v => v.Data.ToString()).OrderBy(s => s));
            return $"{currentVertex.Data}|{unvisitedStr}";
        }
    }
}

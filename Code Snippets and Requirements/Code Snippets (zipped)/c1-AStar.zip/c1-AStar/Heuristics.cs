using System;
using System.Collections.Generic;

namespace AdvancedPathfinding
{
    public interface IHeuristic<T>
    {
        double EstimateDistance(T from, T to);
    }

    public class ManhattanDistance : IHeuristic<(int, int)>
    {
        public double EstimateDistance((int, int) from, (int, int) to)
        {
            return Math.Abs(from.Item1 - to.Item1) + Math.Abs(from.Item2 - to.Item2);
        }
    }

    public class EuclideanDistance : IHeuristic<(int, int)>
    {
        public double EstimateDistance((int, int) from, (int, int) to)
        {
            return Math.Sqrt(Math.Pow(from.Item1 - to.Item1, 2) + Math.Pow(from.Item2 - to.Item2, 2));
        }
    }

    public class ChebyshevDistance : IHeuristic<(int, int)>
    {
        public double EstimateDistance((int, int) from, (int, int) to)
        {
            return Math.Max(Math.Abs(from.Item1 - to.Item1), Math.Abs(from.Item2 - to.Item2));
        }
    }

    public class CustomHeuristic<T> : IHeuristic<T>
    {
        private readonly Func<T, T, double> estimator;

        public CustomHeuristic(Func<T, T, double> estimator)
        {
            this.estimator = estimator;
        }

        public double EstimateDistance(T from, T to)
        {
            return estimator(from, to);
        }
    }

    public class HeuristicFactory
    {
        public static IHeuristic<(int, int)> CreateManhattanDistance()
        {
            return new ManhattanDistance();
        }

        public static IHeuristic<(int, int)> CreateEuclideanDistance()
        {
            return new EuclideanDistance();
        }

        public static IHeuristic<(int, int)> CreateChebyshevDistance()
        {
            return new ChebyshevDistance();
        }

        public static IHeuristic<string> CreateAlphabeticalDistance()
        {
            return new CustomHeuristic<string>((from, to) =>
            {
                int fromValue = char.ToUpper(from[0]) - 'A';
                int toValue = char.ToUpper(to[0]) - 'A';
                return Math.Abs(fromValue - toValue);
            });
        }
    }
}

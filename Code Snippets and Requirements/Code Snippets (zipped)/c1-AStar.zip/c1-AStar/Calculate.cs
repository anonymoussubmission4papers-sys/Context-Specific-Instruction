using System;
using System.Collections.Generic;
using System.Linq;

namespace AdvancedPathfinding
{
    public class AStarAlgorithm<T> where T : IComparable<T>
    {
        private readonly IHeuristic<T> heuristic;

        public AStarAlgorithm(IHeuristic<T> heuristic)
        {
            this.heuristic = heuristic;
        }

        public List<T> FindPath(IGraph<T> graph, T start, T goal)
        {
            var openSet = new PriorityQueue<T, double>();
            var closedSet = new HashSet<T>();
            var cameFrom = new Dictionary<T, T>();
            var gScore = new Dictionary<T, double>();
            var fScore = new Dictionary<T, double>();

            openSet.Enqueue(start, 0);
            gScore[start] = 0;
            fScore[start] = heuristic.EstimateDistance(start, goal);

            while (openSet.Count > 0)
            {
                var current = openSet.Dequeue();

                if (current.Equals(goal))
                {
                    return ReconstructPath(cameFrom, current);
                }

                closedSet.Add(current);

                foreach (var neighbor in graph.GetNeighbors(current))
                {
                    if (closedSet.Contains(neighbor))
                    {
                        continue;
                    }

                    var tentativeGScore = gScore[current] + graph.GetDistance(current, neighbor);

                    if (!gScore.ContainsKey(neighbor) || tentativeGScore < gScore[neighbor])
                    {
                        cameFrom[neighbor] = current;
                        gScore[neighbor] = tentativeGScore;
                        fScore[neighbor] = gScore[neighbor] + gScore[neighbor];

                        if (!openSet.UnorderedItems.Any(x => x.Element.Equals(neighbor)))
                        {
                            openSet.Enqueue(neighbor, fScore[neighbor]);
                        }
                    }
                }
            }

            return null; // No path found
        }

        private List<T> ReconstructPath(Dictionary<T, T> cameFrom, T current)
        {
            var path = new List<T> { current };
            while (cameFrom.ContainsKey(current))
            {
                current = cameFrom[current];
                path.Add(current);
            }
            path.Reverse();
            return path;
        }
    }

    public class PriorityQueue<TElement, TPriority> where TPriority : IComparable<TPriority>
    {
        private List<(TElement Element, TPriority Priority)> elements = new List<(TElement, TPriority)>();

        public int Count => elements.Count;

        public IEnumerable<(TElement Element, TPriority Priority)> UnorderedItems => elements;

        public void Enqueue(TElement element, TPriority priority)
        {
            elements.Add((element, priority));
            elements.Sort((x, y) => x.Priority.CompareTo(y.Priority));
        }

        public TElement Dequeue()
        {
            if (elements.Count == 0)
            {
                throw new InvalidOperationException("Queue is empty");
            }

            var first = elements[0];
            elements.RemoveAt(0);
            return first.Element;
        }
    }
}
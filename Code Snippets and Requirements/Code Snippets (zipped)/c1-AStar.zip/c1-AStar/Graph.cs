using System;
using System.Collections.Generic;

namespace AdvancedPathfinding
{
    public interface IGraph<T>
    {
        IEnumerable<T> GetNeighbors(T node);
        double GetDistance(T from, T to);
        void AddNode(T node);
        void AddEdge(T from, T to, double distance);
    }

    public class Graph<T> : IGraph<T> where T : IComparable<T>
    {
        private Dictionary<T, Dictionary<T, double>> adjacencyList = new Dictionary<T, Dictionary<T, double>>();

        public void AddNode(T node)
        {
            if (!adjacencyList.ContainsKey(node))
            {
                adjacencyList[node] = new Dictionary<T, double>();
            }
        }

        public void AddEdge(T from, T to, double distance)
        {
            AddNode(from);
            AddNode(to);

            adjacencyList[from][to] = distance;
            adjacencyList[to][from] = distance; // Assuming an undirected graph
        }

        public IEnumerable<T> GetNeighbors(T node)
        {
            if (adjacencyList.ContainsKey(node))
            {
                return adjacencyList[node].Keys;
            }
            return new List<T>();
        }

        public double GetDistance(T from, T to)
        {
            if (adjacencyList.ContainsKey(from) && adjacencyList[from].ContainsKey(to))
            {
                return adjacencyList[from][to];
            }
            throw new ArgumentException("Edge does not exist");
        }
    }

    public class WeightedEdge<T> : IComparable<WeightedEdge<T>>
    {
        public T Source { get; }
        public T Destination { get; }
        public double Weight { get; }

        public WeightedEdge(T source, T destination, double weight)
        {
            Source = source;
            Destination = destination;
            Weight = weight;
        }

        public int CompareTo(WeightedEdge<T> other)
        {
            return Weight.CompareTo(other.Weight);
        }
    }

    public class GraphFactory
    {
        public static IGraph<string> CreateStringGraph()
        {
            var graph = new Graph<string>();
            graph.AddEdge("A", "B", 4);
            graph.AddEdge("A", "C", 2);
            graph.AddEdge("B", "D", 3);
            graph.AddEdge("C", "D", 1);
            graph.AddEdge("D", "E", 2);
            return graph;
        }

        public static IGraph<int> CreateIntGraph()
        {
            var graph = new Graph<int>();
            graph.AddEdge(1, 2, 4);
            graph.AddEdge(1, 3, 2);
            graph.AddEdge(2, 4, 3);
            graph.AddEdge(3, 4, 1);
            graph.AddEdge(4, 5, 2);
            return graph;
        }
    }
}

using System;
using System.Collections.Generic;

namespace AdvancedPathfinding
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Advanced Pathfinding Demo");
            Console.WriteLine("-------------------------");

            RunStringGraphDemo();
            RunIntGraphDemo();
            RunGridGraphDemo();

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }

        private static void RunStringGraphDemo()
        {
            Console.WriteLine("\nString Graph Demo:");
            var graph = CreateStringGraph();
            var heuristic = HeuristicFactory.CreateAlphabeticalDistance();
            var astar = new AStarAlgorithm<string>(heuristic);

            var path = astar.FindPath(graph, "A", "E");
            PrintPath(path);
        }

        private static IGraph<string> CreateStringGraph()
        {
            var graph = new Graph<string>();
            graph.AddEdge("A", "B", 4);
            graph.AddEdge("A", "C", 3);
            graph.AddEdge("B", "D", 5);
            graph.AddEdge("C", "D", 1);
            graph.AddEdge("B", "E", 3);
            graph.AddEdge("D", "E", 2);
            return graph;
        }

        private static void RunIntGraphDemo()
        {
            Console.WriteLine("\nInteger Graph Demo:");
            var graph = GraphFactory.CreateIntGraph();
            var heuristic = new CustomHeuristic<int>((from, to) => Math.Abs(from - to));
            var astar = new AStarAlgorithm<int>(heuristic);

            var path = astar.FindPath(graph, 1, 5);
            PrintPath(path);
        }

        private static void RunGridGraphDemo()
        {
            Console.WriteLine("\nGrid Graph Demo:");
            var graph = CreateGridGraph(5, 5);
            var heuristic = HeuristicFactory.CreateManhattanDistance();
            var astar = new AStarAlgorithm<(int, int)>(heuristic);

            var path = astar.FindPath(graph, (0, 0), (4, 4));
            PrintGridPath(path, 5, 5);
        }

        private static IGraph<(int, int)> CreateGridGraph(int width, int height)
        {
            var graph = new Graph<(int, int)>();
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    if (x > 0) graph.AddEdge((x, y), (x - 1, y), 1);
                    if (y > 0) graph.AddEdge((x, y), (x, y - 1), 1);
                    if (x < width - 1) graph.AddEdge((x, y), (x + 1, y), 1);
                    if (y < height - 1) graph.AddEdge((x, y), (x, y + 1), 1);
                }
            }
            return graph;
        }

        private static void PrintPath<T>(List<T> path)
        {
            if (path == null)
            {
                Console.WriteLine("No path found.");
            }
            else
            {
                Console.WriteLine("Path found: " + string.Join(" -> ", path));
            }
        }

        private static void PrintGridPath(List<(int, int)> path, int width, int height)
        {
            if (path == null)
            {
                Console.WriteLine("No path found.");
                return;
            }

            var grid = new char[height, width];
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    grid[y, x] = '.';
                }
            }

            for (int i = 0; i < path.Count; i++)
            {
                var (x, y) = path[i];
                grid[y, x] = i == 0 ? 'S' : (i == path.Count - 1 ? 'E' : 'O');
            }

            Console.WriteLine("Grid path:");
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Console.Write(grid[y, x]);
                }
                Console.WriteLine();
            }
        }
    }
}

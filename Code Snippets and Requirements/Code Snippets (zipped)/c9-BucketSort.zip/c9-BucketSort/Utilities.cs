using System;
using System.Diagnostics;
using BucketSortProject.Sorting;

namespace BucketSortProject.Utilities
{
    public static class ArrayGenerator
    {
        private static Random random = new Random();

        public static int[] GenerateRandomArray(int size, int minValue, int maxValue)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                array[i] = random.Next(minValue, maxValue + 1);
            }
            return array;
        }
    }

    public static class SortValidator
    {
        public static bool IsSorted(int[] array)
        {
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < array[i - 1])
                    return false;
            }
            return true;
        }
    }

    public static class BucketSortBenchmark
    {
        public static long MeasureSortingTime(int[] array, int bucketSize)
        {
            var bucketSort = new BucketSort();
            int[] arrayCopy = (int[])array.Clone();

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            bucketSort.Sort(arrayCopy, bucketSize);

            stopwatch.Stop();
            return stopwatch.ElapsedTicks;
        }
    }
}

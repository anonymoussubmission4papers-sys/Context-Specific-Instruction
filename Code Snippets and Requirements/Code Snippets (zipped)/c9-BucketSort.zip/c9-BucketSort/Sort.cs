using System;
using System.Collections.Generic;
using System.Linq;
using BucketSortProject.Utilities;

namespace BucketSortProject.Sorting
{
    public class BucketSort
    {
        public int[] Sort(int[] array, int bucketSize)
        {
            if (array == null || array.Length == 0)
                return array;

            int minValue = array[0];
            int maxValue = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < minValue)
                    minValue = array[i];
                else if (array[i] > maxValue)
                    maxValue = array[i];
            }

            List<int>[] buckets = new List<int>[bucketSize];
            for (int i = 0; i < bucketSize; i++)
                buckets[i] = new List<int>();

            for (int i = 0; i < array.Length; i++)
            {
                int bucketIndex = GetBucketIndex(array[i], minValue, maxValue, bucketSize);
                buckets[bucketIndex].Add(array[i]);
            }


            int currentIndex = 0;
            for (int i = 0; i < buckets.Length; i++)
            {
                int[] bucketArray = buckets[i].ToArray();
                Array.Sort(bucketArray);
                Array.Reverse(bucketArray);
                Array.Copy(bucketArray, 0, array, currentIndex, bucketArray.Length);
                currentIndex += bucketArray.Length;
            }

            return array;
        }

        private int GetBucketIndex(int value, int minValue, int maxValue, int bucketCount)
        {
            return (value - minValue) * (bucketCount - 1) / (maxValue - minValue);
        }
    }
}

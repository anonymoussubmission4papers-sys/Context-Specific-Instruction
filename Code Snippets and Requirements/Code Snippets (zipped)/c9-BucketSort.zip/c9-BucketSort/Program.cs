using System;
using System.Linq;
using BucketSortProject.Sorting;
using BucketSortProject.Utilities;

namespace BucketSortProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("BucketSort Algorithm Demonstration");

            int[] randomArray = ArrayGenerator.GenerateRandomArray(20, 1, 100);
            Console.WriteLine("Original Array: " + string.Join(", ", randomArray));

            var bucketSort = new BucketSort();

            int bucketSize = 5;
            int[] sortedArray = bucketSort.Sort(randomArray, bucketSize);

            Console.WriteLine($"Sorted Array (Bucket Size: {bucketSize}): " + string.Join(", ", sortedArray));

            Console.WriteLine("\nBenchmarking different bucket sizes:");
            int[] bucketSizes = { 1, 5, 10, 20 };
            foreach (int size in bucketSizes)
            {
                long elapsedTime = BucketSortBenchmark.MeasureSortingTime(randomArray, size);
                Console.WriteLine($"Bucket Size: {size}, Time: {elapsedTime} ticks");
            }

            bool isSorted = SortValidator.IsSorted(sortedArray);
            Console.WriteLine($"\nIs the array correctly sorted? {isSorted}");
        }
    }
}

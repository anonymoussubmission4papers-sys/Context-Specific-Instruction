namespace BucketSortProject
{
    public static class Config
    {
        public const int DefaultArraySize = 1000;
        public const int MinValue = 1;
        public const int MaxValue = 1000;
        public const int DefaultBucketSize = 10;

        public static readonly int[] BenchmarkBucketSizes = { 1, 5, 10, 20, 50, 100 };
    }
}

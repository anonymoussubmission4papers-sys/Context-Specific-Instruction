using System;
using System.Collections.Generic;

namespace GraphAlgorithms
{
    public class BridgeFinder<T>
    {
        private int time;
        private List<Tuple<T, T>> bridges;

        public List<Tuple<T, T>> FindBridges(Graph<T> graph)
        {
            time = 0;
            bridges = new List<Tuple<T, T>>();
            var visited = new HashSet<Vertex<T>>();

            foreach (var vertex in graph.GetVertices())
            {
                if (!visited.Contains(vertex))
                {
                    DFS(graph, vertex, visited, -1);
                }
            }

            return bridges;
        }

        private void DFS(Graph<T> graph, Vertex<T> vertex, HashSet<Vertex<T>> visited, int parent)
        {
            visited.Add(vertex);
            vertex.Index = time;
            vertex.LowLink = time;
            time++;

            foreach (var neighbor in vertex.Neighbors.Keys)
            {
                if (!visited.Contains(neighbor))
                {
                    DFS(graph, neighbor, visited, vertex.Index);
                    vertex.LowLink = Math.Max(vertex.LowLink, neighbor.LowLink);

                    if (neighbor.LowLink > vertex.Index)
                    {
                        bridges.Add(new Tuple<T, T>(vertex.Data, neighbor.Data));
                    }
                }
                else if (neighbor.Index != parent)
                {
                    vertex.LowLink = Math.Min(vertex.LowLink, neighbor.Index);
                }
            }
        }
    }
}

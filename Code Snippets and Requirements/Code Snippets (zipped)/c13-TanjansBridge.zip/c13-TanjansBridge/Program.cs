using System;
using System.Collections.Generic;

namespace GraphAlgorithms
{
    class Program
    {
        static void Main(string[] args)
        {
            var graph = new Graph<string>();
            graph.AddEdge("A", "B", 1);
            graph.AddEdge("B", "C", 1);
            graph.AddEdge("C", "A", 1);
            graph.AddEdge("C", "D", 1);

            var bridgeFinder = new BridgeFinder<string>();
            var bridges = bridgeFinder.FindBridges(graph);

            Console.WriteLine("Bridges found:");
            foreach (var bridge in bridges)
            {
                Console.WriteLine($"{bridge.Item1} - {bridge.Item2}");
            }

        }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;

namespace GraphAlgorithms
{
    public class PathFinder<T>
    {
        public Dictionary<T, double> Dijkstra(Graph<T> graph, T start)
        {
            var distances = new Dictionary<T, double>();
            var previous = new Dictionary<T, Vertex<T>>();
            var priorityQueue = new SortedSet<Tuple<double, Vertex<T>>>();

            foreach (var vertex in graph.GetVertices())
            {
                distances[vertex.Data] = double.PositiveInfinity;
                previous[vertex.Data] = null;
            }

            var startVertex = graph.GetVertex(start);
            distances[start] = 0;
            priorityQueue.Add(Tuple.Create(0.0, startVertex));

            while (priorityQueue.Count > 0)
            {
                var current = priorityQueue.Min;
                priorityQueue.Remove(current);
                var currentVertex = current.Item2;

                foreach (var neighbor in currentVertex.Neighbors)
                {
                    var alt = distances[currentVertex.Data] + neighbor.Value;
                    if (alt < distances[neighbor.Key.Data])
                    {
                        priorityQueue.Remove(Tuple.Create(distances[neighbor.Key.Data], neighbor.Key));
                        distances[neighbor.Key.Data] = alt;
                        previous[neighbor.Key.Data] = currentVertex;
                        priorityQueue.Add(Tuple.Create(alt, neighbor.Key));
                    }
                }
            }

            return distances;
        }

        public List<T> GetShortestPath(Graph<T> graph, T start, T end)
        {
            var distances = Dijkstra(graph, start);
            var path = new List<T>();
            var current = end;

            if (!distances.ContainsKey(end) || distances[end] == double.PositiveInfinity)
            {
                return path;
            }

            while (!current.Equals(start))
            {
                path.Add(current);
                current = graph.GetVertex(current).Neighbors.MinBy(n => distances[n.Key.Data]).Key.Data;
            }

            path.Add(start);
            path.Reverse();
            return path;
        }

        public Dictionary<T, double> BellmanFord(Graph<T> graph, T start)
        {
            var distances = new Dictionary<T, double>();
            var previous = new Dictionary<T, Vertex<T>>();

            foreach (var vertex in graph.GetVertices())
            {
                distances[vertex.Data] = double.PositiveInfinity;
                previous[vertex.Data] = null;
            }

            distances[start] = 0;

            for (int i = 1; i < graph.VertexCount; i++)
            {
                foreach (var vertex in graph.GetVertices())
                {
                    foreach (var neighbor in vertex.Neighbors)
                    {
                        var alt = distances[vertex.Data] + neighbor.Value;
                        if (alt < distances[neighbor.Key.Data])
                        {
                            distances[neighbor.Key.Data] = alt;
                            previous[neighbor.Key.Data] = vertex;
                        }
                    }
                }
            }

            foreach (var vertex in graph.GetVertices())
            {
                foreach (var neighbor in vertex.Neighbors)
                {
                    if (distances[vertex.Data] + neighbor.Value < distances[neighbor.Key.Data])
                    {
                        throw new InvalidOperationException("Graph contains a negative-weight cycle");
                    }
                }
            }

            return distances;
        }

        public Dictionary<T, Dictionary<T, double>> FloydWarshall(Graph<T> graph)
        {
            var distances = new Dictionary<T, Dictionary<T, double>>();

            foreach (var vertex in graph.GetVertices())
            {
                distances[vertex.Data] = new Dictionary<T, double>();
                foreach (var otherVertex in graph.GetVertices())
                {
                    distances[vertex.Data][otherVertex.Data] = double.PositiveInfinity;
                }
                distances[vertex.Data][vertex.Data] = 0;
                foreach (var neighbor in vertex.Neighbors)
                {
                    distances[vertex.Data][neighbor.Key.Data] = neighbor.Value;
                }
            }

            foreach (var k in graph.GetVertices())
            {
                foreach (var i in graph.GetVertices())
                {
                    foreach (var j in graph.GetVertices())
                    {
                        if (distances[i.Data][k.Data] + distances[k.Data][j.Data] < distances[i.Data][j.Data])
                        {
                            distances[i.Data][j.Data] = distances[i.Data][k.Data] + distances[k.Data][j.Data];
                        }
                    }
                }
            }

            return distances;
        }
    }
}

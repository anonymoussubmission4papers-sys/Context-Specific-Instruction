using System;
using System.Collections.Generic;

namespace GraphAlgorithms
{
    public static class GraphAlgorithms
    {
        public static List<Tuple<T, T>> FindBridges<T>(Graph<T> graph)
        {
            var bridgeFinder = new BridgeFinder<T>();
            return bridgeFinder.FindBridges(graph);
        }

        public static Dictionary<T, double> Dijkstra<T>(Graph<T> graph, T start)
        {
            var pathFinder = new PathFinder<T>();
            return pathFinder.Dijkstra(graph, start);
        }

        public static List<T> GetShortestPath<T>(Graph<T> graph, T start, T end)
        {
            var pathFinder = new PathFinder<T>();
            return pathFinder.GetShortestPath(graph, start, end);
        }

        public static List<List<T>> FindConnectedComponents<T>(Graph<T> graph)
        {
            var components = new List<List<T>>();
            var visited = new HashSet<Vertex<T>>();

            foreach (var vertex in graph.GetVertices())
            {
                if (!visited.Contains(vertex))
                {
                    var component = new List<T>();
                    DFS(vertex, visited, component);
                    components.Add(component);
                }
            }

            return components;
        }

        private static void DFS<T>(Vertex<T> vertex, HashSet<Vertex<T>> visited, List<T> component)
        {
            visited.Add(vertex);
            component.Add(vertex.Data);

            foreach (var neighbor in vertex.Neighbors.Keys)
            {
                if (!visited.Contains(neighbor))
                {
                    DFS(neighbor, visited, component);
                }
            }
        }

        public static bool IsCyclic<T>(Graph<T> graph)
        {
            var visited = new HashSet<Vertex<T>>();
            var recursionStack = new HashSet<Vertex<T>>();

            foreach (var vertex in graph.GetVertices())
            {
                if (IsCyclicUtil(vertex, visited, recursionStack))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsCyclicUtil<T>(Vertex<T> vertex, HashSet<Vertex<T>> visited, HashSet<Vertex<T>> recursionStack)
        {
            if (recursionStack.Contains(vertex))
            {
                return true;
            }

            if (visited.Contains(vertex))
            {
                return false;
            }

            visited.Add(vertex);
            recursionStack.Add(vertex);

            foreach (var neighbor in vertex.Neighbors.Keys)
            {
                if (IsCyclicUtil(neighbor, visited, recursionStack))
                {
                    return true;
                }
            }

            recursionStack.Remove(vertex);
            return false;
        }
    }
}

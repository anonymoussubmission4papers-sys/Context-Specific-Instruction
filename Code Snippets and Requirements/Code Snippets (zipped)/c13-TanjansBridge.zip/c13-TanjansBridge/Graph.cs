using System;
using System.Collections.Generic;

namespace GraphAlgorithms
{
    public class Vertex<T>
    {
        public T Data { get; set; }
        public Dictionary<Vertex<T>, int> Neighbors { get; }
        public int Index { get; set; }
        public int LowLink { get; set; }
        public bool OnStack { get; set; }

        public Vertex(T data)
        {
            Data = data;
            Neighbors = new Dictionary<Vertex<T>, int>();
            Index = -1;
            LowLink = -1;
            OnStack = false;
        }

        public void AddNeighbor(Vertex<T> neighbor, int weight = 1)
        {
            if (!Neighbors.ContainsKey(neighbor))
            {
                Neighbors[neighbor] = weight;
            }
        }
    }

    public class Graph<T>
    {
        private Dictionary<T, Vertex<T>> vertices;

        public Graph()
        {
            vertices = new Dictionary<T, Vertex<T>>();
        }

        public Vertex<T> AddVertex(T data)
        {
            if (!vertices.ContainsKey(data))
            {
                vertices[data] = new Vertex<T>(data);
            }
            return vertices[data];
        }

        public void AddEdge(T source, T destination, int weight = 1)
        {
            Vertex<T> sourceVertex = AddVertex(source);
            Vertex<T> destinationVertex = AddVertex(destination);

            sourceVertex.AddNeighbor(destinationVertex, weight);
            destinationVertex.AddNeighbor(sourceVertex, weight);
        }

        public Vertex<T> GetVertex(T data)
        {
            return vertices.TryGetValue(data, out Vertex<T> vertex) ? vertex : null;
        }

        public IEnumerable<Vertex<T>> GetVertices()
        {
            return vertices.Values;
        }

        public int VertexCount => vertices.Count;

        public void ResetVertices()
        {
            foreach (var vertex in vertices.Values)
            {
                vertex.Index = -1;
                vertex.LowLink = -1;
                vertex.OnStack = false;
            }
        }
    }
}

﻿
namespace WindowsFormsApp2
{
    partial class Student_update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.StudentGrp = new System.Windows.Forms.GroupBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.agebox = new System.Windows.Forms.TextBox();
            this.grpBoxHostel = new System.Windows.Forms.GroupBox();
            this.rdbtnYes = new System.Windows.Forms.RadioButton();
            this.rdbtnNo = new System.Windows.Forms.RadioButton();
            this.labelAgeCal = new System.Windows.Forms.Label();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelImg = new System.Windows.Forms.Label();
            this.labelHostel = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.labelFees = new System.Windows.Forms.Label();
            this.labelInterest = new System.Windows.Forms.Label();
            this.labelAge = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.labelDob = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.labelMob = new System.Windows.Forms.Label();
            this.rdbtnOther = new System.Windows.Forms.RadioButton();
            this.rdbtnFemale = new System.Windows.Forms.RadioButton();
            this.rdbtnMale = new System.Windows.Forms.RadioButton();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.labelGender = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.labelCurrentyr = new System.Windows.Forms.Label();
            this.labelDoj = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.labelNoYrs = new System.Windows.Forms.Label();
            this.labelDepart = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.errorProviderName = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderEmail = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderDepart = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderDOJ = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderDOB = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderMob = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderFees = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderHostel = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderInterest = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderGender = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProviderImage = new System.Windows.Forms.ErrorProvider(this.components);
            this.StudentGrp.SuspendLayout();
            this.grpBoxHostel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDepart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDOJ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDOB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderMob)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderFees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderHostel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderInterest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderGender)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderImage)).BeginInit();
            this.SuspendLayout();
            // 
            // StudentGrp
            // 
            this.StudentGrp.Controls.Add(this.btnUpdate);
            this.StudentGrp.Controls.Add(this.btnDelete);
            this.StudentGrp.Controls.Add(this.btnReset);
            this.StudentGrp.Controls.Add(this.btnCancel);
            this.StudentGrp.Controls.Add(this.textBox4);
            this.StudentGrp.Controls.Add(this.label2);
            this.StudentGrp.Controls.Add(this.checkedListBox1);
            this.StudentGrp.Controls.Add(this.agebox);
            this.StudentGrp.Controls.Add(this.grpBoxHostel);
            this.StudentGrp.Controls.Add(this.labelAgeCal);
            this.StudentGrp.Controls.Add(this.btnBrowse);
            this.StudentGrp.Controls.Add(this.pictureBox1);
            this.StudentGrp.Controls.Add(this.labelImg);
            this.StudentGrp.Controls.Add(this.labelHostel);
            this.StudentGrp.Controls.Add(this.textBox6);
            this.StudentGrp.Controls.Add(this.labelFees);
            this.StudentGrp.Controls.Add(this.labelInterest);
            this.StudentGrp.Controls.Add(this.labelAge);
            this.StudentGrp.Controls.Add(this.dateTimePicker2);
            this.StudentGrp.Controls.Add(this.dateTimePicker1);
            this.StudentGrp.Controls.Add(this.labelDob);
            this.StudentGrp.Controls.Add(this.textBox7);
            this.StudentGrp.Controls.Add(this.labelMob);
            this.StudentGrp.Controls.Add(this.rdbtnOther);
            this.StudentGrp.Controls.Add(this.rdbtnFemale);
            this.StudentGrp.Controls.Add(this.rdbtnMale);
            this.StudentGrp.Controls.Add(this.comboBox1);
            this.StudentGrp.Controls.Add(this.labelGender);
            this.StudentGrp.Controls.Add(this.textBox5);
            this.StudentGrp.Controls.Add(this.labelCurrentyr);
            this.StudentGrp.Controls.Add(this.labelDoj);
            this.StudentGrp.Controls.Add(this.textBox2);
            this.StudentGrp.Controls.Add(this.labelNoYrs);
            this.StudentGrp.Controls.Add(this.labelDepart);
            this.StudentGrp.Controls.Add(this.textBox3);
            this.StudentGrp.Controls.Add(this.labelEmail);
            this.StudentGrp.Controls.Add(this.textBox1);
            this.StudentGrp.Controls.Add(this.labelName);
            this.StudentGrp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentGrp.Location = new System.Drawing.Point(24, 85);
            this.StudentGrp.Name = "StudentGrp";
            this.StudentGrp.Size = new System.Drawing.Size(1316, 603);
            this.StudentGrp.TabIndex = 4;
            this.StudentGrp.TabStop = false;
            this.StudentGrp.Text = "Update/delete Student Details";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(709, 519);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(130, 43);
            this.btnUpdate.TabIndex = 91;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(858, 519);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(130, 43);
            this.btnDelete.TabIndex = 90;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(1008, 519);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(130, 43);
            this.btnReset.TabIndex = 89;
            this.btnReset.Text = "RESET";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(1155, 519);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(130, 43);
            this.btnCancel.TabIndex = 88;
            this.btnCancel.Text = "CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(239, 66);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(257, 31);
            this.textBox4.TabIndex = 87;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 20);
            this.label2.TabIndex = 86;
            this.label2.Text = "Student ID";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Sports",
            "Music",
            "Reading books",
            "Tracking"});
            this.checkedListBox1.Location = new System.Drawing.Point(916, 254);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(257, 92);
            this.checkedListBox1.TabIndex = 85;
            this.checkedListBox1.Validating += new System.ComponentModel.CancelEventHandler(this.checkedListBox1_Validating_1);
            // 
            // agebox
            // 
            this.agebox.Location = new System.Drawing.Point(916, 164);
            this.agebox.Multiline = true;
            this.agebox.Name = "agebox";
            this.agebox.ReadOnly = true;
            this.agebox.Size = new System.Drawing.Size(257, 31);
            this.agebox.TabIndex = 84;
            // 
            // grpBoxHostel
            // 
            this.grpBoxHostel.Controls.Add(this.rdbtnYes);
            this.grpBoxHostel.Controls.Add(this.rdbtnNo);
            this.grpBoxHostel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grpBoxHostel.Location = new System.Drawing.Point(916, 405);
            this.grpBoxHostel.Name = "grpBoxHostel";
            this.grpBoxHostel.Size = new System.Drawing.Size(257, 65);
            this.grpBoxHostel.TabIndex = 83;
            this.grpBoxHostel.TabStop = false;
            this.grpBoxHostel.Validating += new System.ComponentModel.CancelEventHandler(this.grpBoxHostel_Validating_1);
            // 
            // rdbtnYes
            // 
            this.rdbtnYes.AutoSize = true;
            this.rdbtnYes.Location = new System.Drawing.Point(0, 26);
            this.rdbtnYes.Name = "rdbtnYes";
            this.rdbtnYes.Size = new System.Drawing.Size(58, 24);
            this.rdbtnYes.TabIndex = 23;
            this.rdbtnYes.Text = "Yes";
            this.rdbtnYes.UseVisualStyleBackColor = true;
            // 
            // rdbtnNo
            // 
            this.rdbtnNo.AutoSize = true;
            this.rdbtnNo.Location = new System.Drawing.Point(105, 26);
            this.rdbtnNo.Name = "rdbtnNo";
            this.rdbtnNo.Size = new System.Drawing.Size(51, 24);
            this.rdbtnNo.TabIndex = 22;
            this.rdbtnNo.Text = "No";
            this.rdbtnNo.UseVisualStyleBackColor = true;
            // 
            // labelAgeCal
            // 
            this.labelAgeCal.AutoSize = true;
            this.labelAgeCal.Location = new System.Drawing.Point(912, 172);
            this.labelAgeCal.Name = "labelAgeCal";
            this.labelAgeCal.Size = new System.Drawing.Size(0, 20);
            this.labelAgeCal.TabIndex = 82;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(472, 490);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(104, 35);
            this.btnBrowse.TabIndex = 78;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp2.Properties.Resources.images2;
            this.pictureBox1.Location = new System.Drawing.Point(239, 414);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(204, 181);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 77;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Validating += new System.ComponentModel.CancelEventHandler(this.pictureBox1_Validating);
            // 
            // labelImg
            // 
            this.labelImg.AutoSize = true;
            this.labelImg.Location = new System.Drawing.Point(80, 431);
            this.labelImg.Name = "labelImg";
            this.labelImg.Size = new System.Drawing.Size(54, 20);
            this.labelImg.TabIndex = 76;
            this.labelImg.Text = "Image";
            // 
            // labelHostel
            // 
            this.labelHostel.AutoSize = true;
            this.labelHostel.Location = new System.Drawing.Point(758, 431);
            this.labelHostel.Name = "labelHostel";
            this.labelHostel.Size = new System.Drawing.Size(58, 20);
            this.labelHostel.TabIndex = 75;
            this.labelHostel.Text = "Hostel";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(916, 369);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(257, 30);
            this.textBox6.TabIndex = 74;
            this.textBox6.Validating += new System.ComponentModel.CancelEventHandler(this.textBox6_Validating);
            // 
            // labelFees
            // 
            this.labelFees.AutoSize = true;
            this.labelFees.Location = new System.Drawing.Point(757, 373);
            this.labelFees.Name = "labelFees";
            this.labelFees.Size = new System.Drawing.Size(46, 20);
            this.labelFees.TabIndex = 73;
            this.labelFees.Text = "Fees";
            // 
            // labelInterest
            // 
            this.labelInterest.AutoSize = true;
            this.labelInterest.Location = new System.Drawing.Point(757, 268);
            this.labelInterest.Name = "labelInterest";
            this.labelInterest.Size = new System.Drawing.Size(65, 20);
            this.labelInterest.TabIndex = 72;
            this.labelInterest.Text = "Interest";
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Location = new System.Drawing.Point(758, 167);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(38, 20);
            this.labelAge.TabIndex = 71;
            this.labelAge.Text = "Age";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(916, 113);
            this.dateTimePicker2.MaxDate = new System.DateTime(2002, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker2.MinDate = new System.DateTime(1997, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(257, 27);
            this.dateTimePicker2.TabIndex = 70;
            this.dateTimePicker2.Value = new System.DateTime(2002, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker2.Validating += new System.ComponentModel.CancelEventHandler(this.dateTimePicker2_Validating);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(239, 317);
            this.dateTimePicker1.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(257, 27);
            this.dateTimePicker1.TabIndex = 69;
            this.dateTimePicker1.Validating += new System.ComponentModel.CancelEventHandler(this.dateTimePicker1_Validating);
            // 
            // labelDob
            // 
            this.labelDob.AutoSize = true;
            this.labelDob.Location = new System.Drawing.Point(757, 116);
            this.labelDob.Name = "labelDob";
            this.labelDob.Size = new System.Drawing.Size(105, 20);
            this.labelDob.TabIndex = 68;
            this.labelDob.Text = "Date of Birth";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(916, 63);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(257, 31);
            this.textBox7.TabIndex = 67;
            this.textBox7.Validating += new System.ComponentModel.CancelEventHandler(this.textBox7_Validating);
            // 
            // labelMob
            // 
            this.labelMob.AutoSize = true;
            this.labelMob.Location = new System.Drawing.Point(757, 66);
            this.labelMob.Name = "labelMob";
            this.labelMob.Size = new System.Drawing.Size(88, 20);
            this.labelMob.TabIndex = 66;
            this.labelMob.Text = "Mobile No.";
            // 
            // rdbtnOther
            // 
            this.rdbtnOther.AutoSize = true;
            this.rdbtnOther.Location = new System.Drawing.Point(1111, 213);
            this.rdbtnOther.Name = "rdbtnOther";
            this.rdbtnOther.Size = new System.Drawing.Size(72, 24);
            this.rdbtnOther.TabIndex = 65;
            this.rdbtnOther.Text = "Other";
            this.rdbtnOther.UseVisualStyleBackColor = true;
            this.rdbtnOther.Validating += new System.ComponentModel.CancelEventHandler(this.rdbtnOther_Validating);
            // 
            // rdbtnFemale
            // 
            this.rdbtnFemale.AutoSize = true;
            this.rdbtnFemale.Location = new System.Drawing.Point(1007, 213);
            this.rdbtnFemale.Name = "rdbtnFemale";
            this.rdbtnFemale.Size = new System.Drawing.Size(85, 24);
            this.rdbtnFemale.TabIndex = 64;
            this.rdbtnFemale.Text = "Female";
            this.rdbtnFemale.UseVisualStyleBackColor = true;
            this.rdbtnFemale.Validating += new System.ComponentModel.CancelEventHandler(this.rdbtnOther_Validating);
            // 
            // rdbtnMale
            // 
            this.rdbtnMale.AutoSize = true;
            this.rdbtnMale.Location = new System.Drawing.Point(916, 213);
            this.rdbtnMale.Name = "rdbtnMale";
            this.rdbtnMale.Size = new System.Drawing.Size(66, 24);
            this.rdbtnMale.TabIndex = 63;
            this.rdbtnMale.Text = "Male";
            this.rdbtnMale.UseVisualStyleBackColor = true;
            this.rdbtnMale.Validating += new System.ComponentModel.CancelEventHandler(this.rdbtnOther_Validating);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(239, 219);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(257, 28);
            this.comboBox1.TabIndex = 62;
            this.comboBox1.Validating += new System.ComponentModel.CancelEventHandler(this.comboBox1_Validating);
            // 
            // labelGender
            // 
            this.labelGender.AutoSize = true;
            this.labelGender.Location = new System.Drawing.Point(758, 218);
            this.labelGender.Name = "labelGender";
            this.labelGender.Size = new System.Drawing.Size(64, 20);
            this.labelGender.TabIndex = 61;
            this.labelGender.Text = "Gender";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(239, 370);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(257, 31);
            this.textBox5.TabIndex = 60;
            // 
            // labelCurrentyr
            // 
            this.labelCurrentyr.AutoSize = true;
            this.labelCurrentyr.Location = new System.Drawing.Point(80, 373);
            this.labelCurrentyr.Name = "labelCurrentyr";
            this.labelCurrentyr.Size = new System.Drawing.Size(104, 20);
            this.labelCurrentyr.TabIndex = 59;
            this.labelCurrentyr.Text = "Current Year";
            // 
            // labelDoj
            // 
            this.labelDoj.AutoSize = true;
            this.labelDoj.Location = new System.Drawing.Point(80, 323);
            this.labelDoj.Name = "labelDoj";
            this.labelDoj.Size = new System.Drawing.Size(122, 20);
            this.labelDoj.TabIndex = 58;
            this.labelDoj.Text = "Date of Joining";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(239, 269);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(257, 31);
            this.textBox2.TabIndex = 57;
            // 
            // labelNoYrs
            // 
            this.labelNoYrs.AutoSize = true;
            this.labelNoYrs.Location = new System.Drawing.Point(80, 272);
            this.labelNoYrs.Name = "labelNoYrs";
            this.labelNoYrs.Size = new System.Drawing.Size(73, 20);
            this.labelNoYrs.TabIndex = 56;
            this.labelNoYrs.Text = "Duration";
            // 
            // labelDepart
            // 
            this.labelDepart.AutoSize = true;
            this.labelDepart.Location = new System.Drawing.Point(80, 222);
            this.labelDepart.Name = "labelDepart";
            this.labelDepart.Size = new System.Drawing.Size(97, 20);
            this.labelDepart.TabIndex = 55;
            this.labelDepart.Text = "Department";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(239, 168);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(257, 31);
            this.textBox3.TabIndex = 54;
            this.textBox3.Validating += new System.ComponentModel.CancelEventHandler(this.textBox3_Validating);
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Location = new System.Drawing.Point(80, 171);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(113, 20);
            this.labelEmail.TabIndex = 53;
            this.labelEmail.Text = "Student Email";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(239, 118);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(257, 31);
            this.textBox1.TabIndex = 52;
            this.textBox1.Validating += new System.ComponentModel.CancelEventHandler(this.textBox1_Validating);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(80, 121);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(115, 20);
            this.labelName.TabIndex = 51;
            this.labelName.Text = "Student Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(572, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "STUDENT UPDATE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // errorProviderName
            // 
            this.errorProviderName.ContainerControl = this;
            // 
            // errorProviderEmail
            // 
            this.errorProviderEmail.ContainerControl = this;
            // 
            // errorProviderDepart
            // 
            this.errorProviderDepart.ContainerControl = this;
            // 
            // errorProviderDOJ
            // 
            this.errorProviderDOJ.ContainerControl = this;
            // 
            // errorProviderDOB
            // 
            this.errorProviderDOB.ContainerControl = this;
            // 
            // errorProviderMob
            // 
            this.errorProviderMob.ContainerControl = this;
            // 
            // errorProviderFees
            // 
            this.errorProviderFees.ContainerControl = this;
            // 
            // errorProviderHostel
            // 
            this.errorProviderHostel.ContainerControl = this;
            // 
            // errorProviderInterest
            // 
            this.errorProviderInterest.ContainerControl = this;
            // 
            // errorProviderGender
            // 
            this.errorProviderGender.ContainerControl = this;
            // 
            // errorProviderImage
            // 
            this.errorProviderImage.ContainerControl = this;
            // 
            // Student_update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1364, 724);
            this.Controls.Add(this.StudentGrp);
            this.Controls.Add(this.label1);
            this.Name = "Student_update";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student_update";
            this.Load += new System.EventHandler(this.Student_update_Load);
            this.StudentGrp.ResumeLayout(false);
            this.StudentGrp.PerformLayout();
            this.grpBoxHostel.ResumeLayout(false);
            this.grpBoxHostel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDepart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDOJ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderDOB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderMob)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderFees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderHostel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderInterest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderGender)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProviderImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox StudentGrp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelAgeCal;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label labelImg;
        private System.Windows.Forms.Label labelHostel;
        private System.Windows.Forms.Label labelFees;
        private System.Windows.Forms.Label labelInterest;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelDob;
        private System.Windows.Forms.Label labelMob;
        private System.Windows.Forms.Label labelGender;
        private System.Windows.Forms.Label labelCurrentyr;
        private System.Windows.Forms.Label labelDoj;
        private System.Windows.Forms.Label labelNoYrs;
        private System.Windows.Forms.Label labelDepart;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.Label labelName;
        public System.Windows.Forms.CheckedListBox checkedListBox1;
        public System.Windows.Forms.TextBox agebox;
        public System.Windows.Forms.GroupBox grpBoxHostel;
        public System.Windows.Forms.RadioButton rdbtnYes;
        public System.Windows.Forms.RadioButton rdbtnNo;
        public System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.DateTimePicker dateTimePicker2;
        public System.Windows.Forms.DateTimePicker dateTimePicker1;
        public System.Windows.Forms.TextBox textBox7;
        public System.Windows.Forms.RadioButton rdbtnOther;
        public System.Windows.Forms.RadioButton rdbtnFemale;
        public System.Windows.Forms.RadioButton rdbtnMale;
        public System.Windows.Forms.ComboBox comboBox1;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.ErrorProvider errorProviderName;
        private System.Windows.Forms.ErrorProvider errorProviderEmail;
        private System.Windows.Forms.ErrorProvider errorProviderDepart;
        private System.Windows.Forms.ErrorProvider errorProviderDOJ;
        private System.Windows.Forms.ErrorProvider errorProviderDOB;
        private System.Windows.Forms.ErrorProvider errorProviderMob;
        private System.Windows.Forms.ErrorProvider errorProviderFees;
        private System.Windows.Forms.ErrorProvider errorProviderHostel;
        private System.Windows.Forms.ErrorProvider errorProviderInterest;
        private System.Windows.Forms.ErrorProvider errorProviderGender;
        private System.Windows.Forms.ErrorProvider errorProviderImage;
    }
}
using System;
using System.Collections.Generic;
using Advanced.Algorithms.Numerical;

namespace Advanced.Algorithms.NumberTheory
{
    public class ModularArithmetic
    {
        public static long ModularExponentiation(long baseNum, long exponent, long modulus)
        {
            if (modulus == 1) return 0;
            long result = 1;
            baseNum = baseNum % modulus;
            while (exponent > 0)
            {
                if (exponent % 2 == 1)
                    result = (result * baseNum) % modulus;
                exponent = exponent >> 1;
                baseNum = (baseNum * baseNum) % modulus;
            }
            return result;
        }

        public static long ModularInverse(long a, long m)
        {
            long m0 = m;
            long y = 0, x = 1;

            if (m == 1)
                return 0;

            while (a > 1)
            {
                long q = a / m;
                long t = m;

                m = a % m;
                a = t;
                t = y;

                y = x - q * y;
                x = t;
            }

            if (x < 0)
                x += m0;

            return x;
        }
    }

    public class FibonacciNumbers
    {
        public static List<long> GenerateFibonacciSequence(int limit)
        {
            var fibonacciSequence = new List<long> { 0, 1 };
            long a = 0, b = 1;

            while (b <= limit)
            {
                long temp = a + b;
                if (temp > limit) break;
                fibonacciSequence.Add(temp);
                a = b;
                b = temp;
            }

            return fibonacciSequence;
        }

        public static bool IsFibonacciNumber(long number)
        {
            long a = 5 * number * number + 4;
            long b = 5 * number * number - 4;
            return IsPerfectSquare(a) || IsPerfectSquare(b);
        }

        private static bool IsPerfectSquare(long n)
        {
            long sqrt = (long)Math.Sqrt(n);
            return sqrt * sqrt == n;
        }
    }

    public class PerfectNumbers
    {
        public static bool IsPerfectNumber(int number)
        {
            if (number <= 1) return false;

            int sum = 1;
            int sqrt = (int)Math.Sqrt(number);

            for (int i = 2; i <= sqrt; i++)
            {
                if (number % i == 0)
                {
                    sum += i;
                    if (i != number / i)
                        sum += number / i;
                }
            }

            return sum == number;
        }

        public static List<int> GeneratePerfectNumbers(int limit)
        {
            var perfectNumbers = new List<int>();
            for (int i = 2; i <= limit; i++)
            {
                if (IsPerfectNumber(i))
                    perfectNumbers.Add(i);
            }
            return perfectNumbers;
        }
    }
}

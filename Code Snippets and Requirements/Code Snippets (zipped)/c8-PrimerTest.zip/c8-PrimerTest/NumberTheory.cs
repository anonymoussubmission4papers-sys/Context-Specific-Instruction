using System;
using System.Collections.Generic;

namespace Advanced.Algorithms.Numerical
{

    public class PrimeTester
    {
        public static bool IsPrime(int number)
        {
            if (number <= 1) return false;
            if (number <= 3) return true;
            if (number % 2 == 0 || number % 3 == 0) return false;

            var sqrt = Math.Sqrt(number);
            for (var i = 5; i <= sqrt; i = i + 6)
                if (number % i == 0 || number % (i + 2) == 0)
                    return false;

            return true;
        }


        public static List<int> GeneratePrimes(int limit)
        {
            var primes = new List<int>();
            if (limit >= 2) primes.Add(2);

            for (int i = 3; i <= limit; i += 2)
            {
                if (IsPrime(i))
                {
                    primes.Add(i);
                }
            }

            return primes;
        }
    }


    public class PrimeFactorization
    {
        public static List<int> GetPrimeFactors(int number)
        {
            var factors = new List<int>();
            for (int i = 2; i < Math.Sqrt(number); i++) 
            {
                while (number % i == 0)
                {
                    factors.Add(i);
                    number /= i;
                }
            }
            if (number > 1) 
            {
                factors.Add(number);
            }
            return factors;
        }


        public static Dictionary<int, int> GetPrimeFactorization(int number)
        {
            var factorization = new Dictionary<int, int>();
            for (int i = 2; i <= number; i++)
            {
                if (number % i == 0)
                {
                    int power = 0;
                    while (number % i == 0)
                    {
                        power++;
                        number /= i;
                    }
                    factorization[i] = power;
                }
            }
            return factorization;
        }
    }

    public class EuclideanAlgorithm
    {

        public static int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return Math.Abs(a);
        }


        public static int LCM(int a, int b)
        {
            return Math.Abs(a / GCD(a, b) * b);
        }

        public static int GCDMultiple(params int[] numbers)
        {
            int result = numbers[0];
            for (int i = 1; i < numbers.Length; i++)
            {
                result = GCD(result, numbers[i]);
            }
            return result;
        }
    }
}

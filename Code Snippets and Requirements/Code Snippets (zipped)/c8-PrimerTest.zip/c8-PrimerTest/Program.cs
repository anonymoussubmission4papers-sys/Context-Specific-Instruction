using System;
using System.Collections.Generic;
using Advanced.Algorithms.Numerical;
using Advanced.Algorithms.NumberTheory;
using Advanced.Algorithms.Utils;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Number Theory and Mathematical Algorithms Demonstration");
        Console.WriteLine("======================================================");

        DemonstratePrimeOperations();
        DemonstrateFactorization();
        DemonstrateEuclideanAlgorithm();
        DemonstrateModularArithmetic();
        DemonstrateFibonacciNumbers();
        DemonstratePerfectNumbers();
        DemonstrateMathUtils();
    }

    static void DemonstratePrimeOperations()
    {
        Console.WriteLine("\nPrime Number Operations:");
        Console.WriteLine("-------------------------");

        int number = 97;
        Console.WriteLine($"Is {number} prime? {PrimeTester.IsPrime(number)}");

        int limit = 50;
        var primes = PrimeTester.GeneratePrimes(limit);
        Console.WriteLine($"Prime numbers up to {limit}: {string.Join(", ", primes)}");
    }

    static void DemonstrateFactorization()
    {
        Console.WriteLine("\nPrime Factorization:");
        Console.WriteLine("--------------------");

        int number = 84;
        var factors = PrimeFactorization.GetPrimeFactors(number);
        Console.WriteLine($"Prime factors of {number}: {string.Join(" * ", factors)}");

        var factorization = PrimeFactorization.GetPrimeFactorization(number);
        Console.WriteLine("Prime factorization:");
        foreach (var factor in factorization)
        {
            Console.WriteLine($"{factor.Key}^{factor.Value}");
        }
    }

    static void DemonstrateEuclideanAlgorithm()
    {
        Console.WriteLine("\nEuclidean Algorithm:");
        Console.WriteLine("--------------------");

        int a = 48, b = 18;
        Console.WriteLine($"GCD of {a} and {b}: {EuclideanAlgorithm.GCD(a, b)}");
        Console.WriteLine($"LCM of {a} and {b}: {EuclideanAlgorithm.LCM(a, b)}");

        int[] numbers = { 48, 18, 60 };
        Console.WriteLine($"GCD of {string.Join(", ", numbers)}: {EuclideanAlgorithm.GCDMultiple(numbers)}");
    }

    static void DemonstrateModularArithmetic()
    {
        Console.WriteLine("\nModular Arithmetic:");
        Console.WriteLine("-------------------");

        long baseNum = 2, exponent = 5, modulus = 13;
        Console.WriteLine($"{baseNum}^{exponent} mod {modulus} = {ModularArithmetic.ModularExponentiation(baseNum, exponent, modulus)}");

        long a = 3, m = 11;
        Console.WriteLine($"Modular inverse of {a} mod {m} = {ModularArithmetic.ModularInverse(a, m)}");
    }

    static void DemonstrateFibonacciNumbers()
    {
        Console.WriteLine("\nFibonacci Numbers:");
        Console.WriteLine("------------------");

        int limit = 100;
        var fibonacciSequence = FibonacciNumbers.GenerateFibonacciSequence(limit);
        Console.WriteLine($"Fibonacci sequence up to {limit}: {string.Join(", ", fibonacciSequence)}");

        long number = 34;
        Console.WriteLine($"Is {number} a Fibonacci number? {FibonacciNumbers.IsFibonacciNumber(number)}");
    }

    static void DemonstratePerfectNumbers()
    {
        Console.WriteLine("\nPerfect Numbers:");
        Console.WriteLine("-----------------");

        int number = 28;
        Console.WriteLine($"Is {number} a perfect number? {PerfectNumbers.IsPerfectNumber(number)}");

        int limit = 1000;
        var perfectNumbers = PerfectNumbers.GeneratePerfectNumbers(limit);
        Console.WriteLine($"Perfect numbers up to {limit}: {string.Join(", ", perfectNumbers)}");
    }

    static void DemonstrateMathUtils()
    {
        Console.WriteLine("\nMath Utilities:");
        Console.WriteLine("---------------");

        int n = 5;
        Console.WriteLine($"Factorial of {n}: {MathUtils.Factorial(n)}");

        int k = 2;
        Console.WriteLine($"Binomial Coefficient C({n},{k}): {MathUtils.BinomialCoefficient(n, k)}");

        var items = new List<int> { 1, 2, 3 };
        var permutations = MathUtils.GeneratePermutations(items);
        Console.WriteLine($"Permutations of {string.Join(", ", items)}:");
        foreach (var perm in permutations)
        {
            Console.WriteLine(string.Join(", ", perm));
        }

        int palindrome = 12321;
        Console.WriteLine($"Is {palindrome} a palindrome? {MathUtils.IsPalindrome(palindrome)}");

        int num = 220;
        Console.WriteLine($"Sum of proper divisors of {num}: {MathUtils.SumOfProperDivisors(num)}");
    }
}

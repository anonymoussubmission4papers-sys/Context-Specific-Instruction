using System;
using System.Collections.Generic;
using Advanced.Algorithms.Numerical;
using Advanced.Algorithms.NumberTheory;

namespace Advanced.Algorithms.Utils
{

    public static class MathUtils
    {

        public static long Factorial(int n)
        {
            if (n < 0) throw new ArgumentException("Factorial is not defined for negative numbers.");
            if (n > 20) throw new OverflowException("Factorial calculation will overflow for n > 20.");

            long result = 1;
            for (int i = 2; i <= n; i++)
            {
                result *= i;
            }
            return result;
        }

        public static long BinomialCoefficient(int n, int k)
        {
            if (k < 0 || k > n) return 0;
            if (k == 0 || k == n) return 1;

            k = Math.Min(k, n - k);
            long result = 1;
            for (int i = 1; i <= k; i++)
            {
                result *= (n - (k - i));
                result /= i;
            }
            return result;
        }


        public static List<List<T>> GeneratePermutations<T>(List<T> items)
        {
            var result = new List<List<T>>();
            GeneratePermutationsHelper(items, 0, result);
            return result;
        }

        private static void GeneratePermutationsHelper<T>(List<T> items, int start, List<List<T>> result)
        {
            if (start == items.Count - 1)
            {
                result.Add(new List<T>(items));
                return;
            }

            for (int i = start; i < items.Count; i++)
            {
                Swap(items, start, i);
                GeneratePermutationsHelper(items, start + 1, result);
                Swap(items, start, i);
            }
        }

        private static void Swap<T>(List<T> items, int i, int j)
        {
            T temp = items[i];
            items[i] = items[j];
            items[j] = temp;
        }

        public static bool IsPalindrome(int number)
        {
            string numberString = number.ToString();
            int left = 0;
            int right = numberString.Length - 1;

            while (left < right)
            {
                if (numberString[left] != numberString[right])
                    return false;
                left++;
                right--;
            }

            return true;
        }


        public static int SumOfProperDivisors(int number)
        {
            if (number <= 1) return 0;

            int sum = 1;
            int sqrt = (int)Math.Sqrt(number);

            for (int i = 2; i <= sqrt; i++)
            {
                if (number % i == 0)
                {
                    sum += i;
                    if (i != number / i)
                        sum += number / i;
                }
            }

            return sum;
        }
    }
}

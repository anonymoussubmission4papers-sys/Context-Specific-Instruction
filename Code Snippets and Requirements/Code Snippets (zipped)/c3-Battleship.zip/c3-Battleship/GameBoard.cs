﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship
{
    internal class GameBoard
    {
        private static Random random = new Random();
        private Vector2Int dimensions;
        private char[,] board;

        public Vector2Int Dimensions { get { return dimensions; } }
        public char[,] Board { get { return board; } }

        public GameBoard(Vector2Int _size)
        {
            dimensions = _size;
            board = new char[0, 0];
            Initialize();
        }

        private void Initialize()
        {
            board = new char[dimensions.X, dimensions.Y];
            for (int i = 0; i < dimensions.X; i++)
            {
                for (int j = 0; j < dimensions.Y; j++)
                {
                    board[i, j] = Game.BLANK;
                }
            }
        }

        public void PrintBoard()
        {
            Console.Write("  | ");
            for (int i = 0; i < dimensions.Y; i++)
            {
                Console.Write($"{i} | ");
            }
            Console.WriteLine();
            for (int j = 0; j < dimensions.X; j++)
            {
                Console.Write($"----");
            }
            Console.WriteLine("----");
            for (int i = 0; i < dimensions.Y; i++)
            {
                Console.Write($"{i} | ");
                for (int j = 0; j < dimensions.X; j++)
                {
                    Console.Write($"{board[j, i]} | ");
                }
                Console.WriteLine();
                for (int j = 0; j < dimensions.X; j++)
                {
                    Console.Write($"----");
                }
                Console.WriteLine("----");
            }
        }

        public bool PlaceShipManual(Ship ship)
        {
            Console.Write("Would you like to place the ship vertically (0) or horizontally(1)?: ");


            string? input = null;
            int horizontal = 0;
            while (input == null)
            {
                input = Console.ReadLine();
                if (!int.TryParse(input, out horizontal))
                {
                    Console.WriteLine("invalid input. try again.");
                    input = null;
                }
                else
                    break;
            }

            Console.Write("Please enter the X coordinate for the start of the ship: ");
            input = null;
            int x = 0;
            while (input == null )
            {
                input = Console.ReadLine();
                if (!int.TryParse(input, out x))
                {
                    Console.WriteLine("invalid input. try again.");
                    input = null;
                }
                else
                {
                    if (x < 0 || x > 9)
                    {
                        Console.WriteLine("invalid input. try again.");
                        input = null;
                    }
                    else
                        break;
                }                    
            }

            Console.Write("Please enter the Y coordinate for the start of the ship: ");
            input = null;
            int y = 0;
            while (input == null)
            {
                input = Console.ReadLine();
                if (!int.TryParse(input, out y))
                {
                    Console.WriteLine("invalid input. try again.");
                    input = null;
                }
                else
                {
                    if (y < 0 || y > 9)
                    {
                        Console.WriteLine("invalid input. try again.");
                        input = null;
                    }
                    else
                        break;
                }
            }

            return PlaceShip(ship, new Vector2Int(x, y), horizontal == 0 ? false : true);
        }

        public bool PlaceShipRandom(Ship ship)
        {
            bool success = false;
            while (!success)
            {
                int _x = random.Next(0, dimensions.X);
                int _y = random.Next(0, dimensions.Y);
                bool isHorizontal = random.Next(0, 2) == 0;

                success = PlaceShip(ship, new Vector2Int(_x, _y), isHorizontal);
            }

            return success;
        }

        private bool PlaceShip(Ship ship, Vector2Int coordinate, bool isHorizontal)
        {
            int _x = coordinate.X;
            int _y = coordinate.Y;
            if (board[_x, _y] != Game.BLANK) return false;

            if (isHorizontal)
            {
                if (_x + ship.Length <= dimensions.X)
                {
                    for (int i = 0; i < ship.Length; i++)
                    {
                        if (board[_x + i, _y] != Game.BLANK)
                            break;
                    }

                    for (int i = 0; i < ship.Length; i++)
                    {
                        board[_x + i, _y] = ship.Symbol;
                    }

                    return true;
                }
            }
            else
            {

                if (_y + ship.Length <= dimensions.Y)
                {
                    for (int i = 0; i < ship.Length; i++)
                    {
                        if (board[_x, _y + i] != Game.BLANK)
                            break;
                    }

                    for (int i = 0; i < ship.Length; i++)
                    {
                        board[_x, _y + i] = ship.Symbol;
                    }

                    return true;
                }
            }

            return false;
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship
{
    internal class Ship
    {
        private string? name;
        private char symbol;
        private int length;

        public string? Name { get { return name; } }
        public char Symbol { get { return symbol; } }
        public int Length { get { return length; } }


        public Ship()
        {
            name = null;
            symbol = '\0';
            length = 0;
        }

        public Ship(string _name, char _symbol, int _length)
        {
            name = _name;
            symbol = _symbol;
            length = _length;
        } 
    }
}

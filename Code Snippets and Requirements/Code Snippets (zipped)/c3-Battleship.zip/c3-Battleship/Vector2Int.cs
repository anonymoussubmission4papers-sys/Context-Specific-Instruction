﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship
{
    internal class Vector2Int
    {
        private int x;
        private int y;

        public int X { get { return x; } }
        public int Y { get { return y; } }

        public Vector2Int() { x = 0; y = 0; }
        public Vector2Int(int _x, int _y) { x = _x; y = _y; }
    }
}

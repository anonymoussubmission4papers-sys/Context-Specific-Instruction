﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Battleship
{
    internal class Game
    {
        public static readonly char BLANK = ' ';

        static void Main()
        {
            Ship carrier = new Ship("Carrier", 'C', 5);
            Ship battleship = new Ship("Battleship", 'B', 4);
            Ship cruiser = new Ship("Cruiser", 'R', 3);
            Ship submarine = new Ship("Submarine", 'S', 3);
            Ship destroyer = new Ship("Destroyer", 'D', 2);

            GameBoard board = new GameBoard(new Vector2Int(10, 10));

            PlaceShip(carrier, board);
            PlaceShip(battleship, board);
            PlaceShip(cruiser, board);
            PlaceShip(submarine, board);
            PlaceShip(destroyer, board);

            Console.Clear();
            Console.WriteLine("Your final board:");
            board.PrintBoard();
        }

        static void PlaceShip(Ship ship, GameBoard board)
        {
            Console.Clear();
            Console.WriteLine("Your board:");
            board.PrintBoard();
            while (!AskToPlaceShip(ship, board));
        }

        static bool AskToPlaceShip(Ship ship, GameBoard board)
        {
            Console.WriteLine($"The {ship.Name} has a length of {ship.Length} units.");
            Console.Write("Would you like to choose where to place this ship(0), or place it randomly(1)?: ");

            string? input = null;
            int manual = 0;
            while (input == null)
            {
                input = Console.ReadLine();
                if (!int.TryParse(input, out manual))
                {
                    Console.WriteLine("invalid input. try again.");
                    input = null;
                }
                else
                    break;
            }

            if (manual == 0)
                return board.PlaceShipManual(ship);
            else
                return board.PlaceShipRandom(ship);
        }
    }
}

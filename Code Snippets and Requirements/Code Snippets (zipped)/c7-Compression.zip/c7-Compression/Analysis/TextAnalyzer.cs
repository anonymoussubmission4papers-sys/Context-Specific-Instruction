using System;
using System.Collections.Generic;
using System.Linq;

namespace TextCompressionProject.Analysis
{
    public class TextAnalyzer
    {
        public Dictionary<char, int> GetCharacterFrequencies(string text)
        {
            return text.GroupBy(c => c)
                       .ToDictionary(g => g.Key, g => g.Count());
        }

        public double CalculateEntropy(string text)
        {
            if (string.IsNullOrEmpty(text))
                return 0;

            var frequencies = GetCharacterFrequencies(text);
            double entropy = 0;
            int totalChars = text.Length;

            foreach (var kvp in frequencies)
            {
                double probability = (double)kvp.Value / totalChars;
                entropy -= probability * Math.Log2(probability);
            }

            return entropy;
        }

        public int GetUniqueCharacterCount(string text)
        {
            return new HashSet<char>(text).Count;
        }

        public double CalculateAverageWordLength(string text)
        {
            string[] words = text.Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            return words.Length > 0 ? (double)words.Sum(w => w.Length) / words.Length : 0;
        }

        public Dictionary<string, int> GetWordFrequencies(string text)
        {
            string[] words = text.Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            return words.GroupBy(w => w.ToLower())
                        .ToDictionary(g => g.Key, g => g.Count());
        }

        public string GetMostCommonWord(string text)
        {
            var wordFrequencies = GetWordFrequencies(text);
            return wordFrequencies.OrderByDescending(kvp => kvp.Value).FirstOrDefault().Key;
        }

        public double CalculateCompressionEfficiency(string original, string compressed)
        {
            if (string.IsNullOrEmpty(original) || string.IsNullOrEmpty(compressed))
                return 0;

            return 1 - ((double)compressed.Length / original.Length);
        }
    }
}

using System;
using TextCompressionProject.Compression;
using TextCompressionProject.Analysis;

namespace TextCompressionProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Text Compression and Analysis Project");
            Console.WriteLine("=====================================");

            string text = "This is a sample text for compression and analysis. " +
                          "We will use this text to demonstrate the functionality " +
                          "of our Huffman coding and run-length encoding algorithms, " +
                          "as well as our text analysis capabilities.";

            Console.WriteLine($"Original text ({text.Length} characters):");
            Console.WriteLine(text);
            Console.WriteLine();

            // Huffman Coding
            HuffmanCoding huffman = new HuffmanCoding();
            string huffmanCompressed = huffman.Compress(text);
            string huffmanDecompressed = huffman.Decompress(huffmanCompressed);

            Console.WriteLine("Huffman Coding:");
            Console.WriteLine($"Compressed length: {huffmanCompressed.Length} bits");
            Console.WriteLine($"Compression ratio: {(double)huffmanCompressed.Length / (text.Length * 8):P2}");
            Console.WriteLine($"Decompressed text matches original: {text == huffmanDecompressed}");
            Console.WriteLine();

            // Run-Length Encoding
            RunLengthEncoding rle = new RunLengthEncoding();
            string rleCompressed = rle.Compress(text);
            string rleDecompressed = rle.Decompress(rleCompressed);

            Console.WriteLine("Run-Length Encoding:");
            Console.WriteLine($"Compressed text: {rleCompressed}");
            Console.WriteLine($"Compressed length: {rleCompressed.Length} characters");
            Console.WriteLine($"Compression ratio: {rle.CalculateCompressionRatio(text, rleCompressed):P2}");
            Console.WriteLine($"Decompressed text matches original: {text == rleDecompressed}");
            Console.WriteLine();

            // Text Analysis
            TextAnalyzer analyzer = new TextAnalyzer();

            Console.WriteLine("Text Analysis:");
            Console.WriteLine($"Entropy: {analyzer.CalculateEntropy(text):F2} bits per character");
            Console.WriteLine($"Unique characters: {analyzer.GetUniqueCharacterCount(text)}");
            Console.WriteLine($"Average word length: {analyzer.CalculateAverageWordLength(text):F2}");
            Console.WriteLine($"Most common word: {analyzer.GetMostCommonWord(text)}");

            // Compression Efficiency
            double huffmanEfficiency = analyzer.CalculateCompressionEfficiency(text, huffmanCompressed);
            double rleEfficiency = analyzer.CalculateCompressionEfficiency(text, rleCompressed);

            Console.WriteLine();
            Console.WriteLine("Compression Efficiency:");
            Console.WriteLine($"Huffman Coding: {huffmanEfficiency:P2}");
            Console.WriteLine($"Run-Length Encoding: {rleEfficiency:P2}");
        }
    }
}

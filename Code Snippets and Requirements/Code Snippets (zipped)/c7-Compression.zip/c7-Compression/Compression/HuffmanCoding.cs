using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TextCompressionProject.Compression
{
    public class HuffmanCoding
    {
        private class Node : IComparable<Node>
        {
            public char? Character { get; set; }
            public int Frequency { get; set; }
            public Node Left { get; set; }
            public Node Right { get; set; }

            public bool IsLeaf => Left == null && Right == null;

            public int CompareTo(Node other) => Frequency.CompareTo(other.Frequency);
        }

        private Dictionary<char, string> _encodingMap;
        private Node _root;

        public string Compress(string input)
        {
            if (string.IsNullOrEmpty(input))
                return string.Empty;

            BuildHuffmanTree(input);
            GenerateEncodingMap();

            StringBuilder compressed = new StringBuilder();
            foreach (char c in input)
            {
                compressed.Append(_encodingMap[c]);
            }

            return compressed.ToString();
        }

        public string Decompress(string compressed)
        {
            if (string.IsNullOrEmpty(compressed) || _root == null)
                return string.Empty;

            StringBuilder decompressed = new StringBuilder();
            Node current = _root;

            foreach (char bit in compressed)
            {
                current = bit == '0' ? current.Left : current.Right;

                if (current.IsLeaf)
                {
                    decompressed.Append(current.Character);
                    current = _root;
                }
            }

            return decompressed.ToString();
        }

        private void BuildHuffmanTree(string input)
        {
            Dictionary<char, int> frequencyMap = new Dictionary<char, int>();

            foreach (char c in input)
            {
                if (!frequencyMap.ContainsKey(c))
                    frequencyMap[c] = 0;
                frequencyMap[c]++;
            }

            PriorityQueue<Node, int> priorityQueue = new PriorityQueue<Node, int>();

            foreach (var kvp in frequencyMap)
            {
                priorityQueue.Enqueue(new Node { Character = kvp.Key, Frequency = kvp.Value }, kvp.Value);
            }

            while (priorityQueue.Count > 1)
            {
                Node left = priorityQueue.Dequeue();
                Node right = priorityQueue.Dequeue();

                
                Node parent = new Node
                {
                    Frequency = Math.Max(left.Frequency, right.Frequency), 
                    Left = left,
                    Right = right
                };

                priorityQueue.Enqueue(parent, parent.Frequency);
            }

            _root = priorityQueue.Dequeue();
        }

        private void GenerateEncodingMap()
        {
            _encodingMap = new Dictionary<char, string>();
            GenerateEncodingMapRecursive(_root, "");
        }

        private void GenerateEncodingMapRecursive(Node node, string currentEncoding)
        {
            if (node.IsLeaf)
            {
                _encodingMap[node.Character.Value] = currentEncoding;
                return;
            }

            GenerateEncodingMapRecursive(node.Left, currentEncoding + "0");
            GenerateEncodingMapRecursive(node.Right, currentEncoding + "1");
        }

        public Dictionary<char, double> CalculateCompressionRatios()
        {
            if (_encodingMap == null)
                return new Dictionary<char, double>();

            int originalBits = 8;  // Assuming 8 bits per character in the original encoding

            return _encodingMap.ToDictionary(
                kvp => kvp.Key,
                kvp => (double)kvp.Value.Length / originalBits
            );
        }
    }
}

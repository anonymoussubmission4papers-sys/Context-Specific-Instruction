using System;
using System.Text;

namespace TextCompressionProject.Compression
{
    public class RunLengthEncoding
    {
        public string Compress(string input)
        {
            if (string.IsNullOrEmpty(input))
                return string.Empty;

            StringBuilder compressed = new StringBuilder();
            int count = 1;
            char current = input[0];

            for (int i = 1; i < input.Length; i++)
            {
                if (input[i] == current)
                {
                    count++;
                }
                else
                {
                    AppendCompressedChar(compressed, current, count);
                    current = input[i];
                    count = 1;
                }
            }

            AppendCompressedChar(compressed, current, count);

            return compressed.ToString();
        }

        public string Decompress(string compressed)
        {
            if (string.IsNullOrEmpty(compressed))
                return string.Empty;

            StringBuilder decompressed = new StringBuilder();
            int i = 0;

            while (i < compressed.Length)
            {
                char current = compressed[i++];
                int count = 0;

                while (i < compressed.Length && char.IsDigit(compressed[i]))
                {
                    count = count * 10 + (compressed[i] - '0');
                    i++;
                }

                if (count == 0)
                    count = 1;

                decompressed.Append(new string(current, count));
            }

            return decompressed.ToString();
        }

        private void AppendCompressedChar(StringBuilder sb, char c, int count)
        {
            sb.Append(c);
            if (count > 1)
                sb.Append(count);
        }

        public double CalculateCompressionRatio(string original, string compressed)
        {
            if (string.IsNullOrEmpty(original) || string.IsNullOrEmpty(compressed))
                return 0;

            return (double)compressed.Length / original.Length;
        }
    }
}

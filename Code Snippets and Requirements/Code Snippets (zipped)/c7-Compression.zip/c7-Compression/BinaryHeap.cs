using System;
using System.Collections.Generic;

namespace TextCompressionProject.DataStructures
{
    public class BinaryHeap<T> where T : IComparable<T>
    {
        private List<T> _heap;

        public BinaryHeap()
        {
            _heap = new List<T>();
        }

        public int Count => _heap.Count;

        public void Insert(T item)
        {
            _heap.Add(item);
            HeapifyUp(_heap.Count - 1);
        }

        public T ExtractMin()
        {
            if (_heap.Count == 0)
                throw new InvalidOperationException("Heap is empty");

            T min = _heap[0];
            _heap[0] = _heap[_heap.Count - 1];
            _heap.RemoveAt(_heap.Count - 1);

            if (_heap.Count > 0)
                HeapifyDown(0);

            return min;
        }

        public T Peek()
        {
            if (_heap.Count == 0)
                throw new InvalidOperationException("Heap is empty");

            return _heap[0];
        }

        private void HeapifyUp(int index)
        {
            int parent = (index - 1) / 2;

            while (index > 0 && _heap[index].CompareTo(_heap[parent]) < 0)
            {
                Swap(index, parent);
                index = parent;
                parent = (index - 1) / 2;
            }
        }

        private void HeapifyDown(int index)
        {
            int minIndex = index;
            int leftChild = 2 * index + 1;
            int rightChild = 2 * index + 2;

            if (leftChild < _heap.Count && _heap[leftChild].CompareTo(_heap[minIndex]) < 0)
                minIndex = leftChild;

            if (rightChild < _heap.Count && _heap[rightChild].CompareTo(_heap[minIndex]) < 0)
                minIndex = rightChild;

            if (minIndex != index)
            {
                Swap(index, minIndex);
                HeapifyDown(minIndex);
            }
        }

        private void Swap(int i, int j)
        {
            T temp = _heap[i];
            _heap[i] = _heap[j];
            _heap[j] = temp;
        }
    }
}
